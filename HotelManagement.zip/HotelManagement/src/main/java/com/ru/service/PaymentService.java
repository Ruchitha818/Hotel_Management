package com.ru.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ru.dao.PaymentRepository;
import com.ru.model.Payment;

@Service
public class PaymentService {

	
	@Autowired
	PaymentRepository pmtRepo;

	public List<Payment> payment() {
		// TODO Auto-generated method stub
		return pmtRepo.findAll();
	}

	
}
